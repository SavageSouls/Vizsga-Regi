import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'

export default function SearchResult() {
    const { searchedWord } = useParams()
    const [result, setResult] = useState([])

    useEffect(() => {
        async function fetchData() {
            try {
                const res  = await fetch(`http://localhost:3333/api/search/${searchedWord.trim()}`)
                const data = await res.json()
                // Some backends wrap in { result: [...] }, others return array directly:
                setResult(Array.isArray(data) ? data : (data.result ?? []))
            } catch (err) {
                console.warn(err)
            }
        }
        fetchData()
    }, [searchedWord])

    return (
        <div style={{ marginTop: '80px', padding: '20px' }}>
            <h2 style={{ textAlign: 'center' }}>
                {result.length === 0
                    ? `Nincs találat: "${searchedWord}"`
                    : `Találatok: "${searchedWord}"`}
            </h2>

            <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: '16px', marginTop: '24px' }}>
                {result.map((item, idx) => (
                    <div key={item?.id ?? idx} style={{
                        width: '280px',
                        backgroundColor: '#fff',
                        borderRadius: '12px',
                        padding: '16px',
                        boxShadow: '0 2px 8px rgba(0,0,0,0.15)',
                    }}>
                        {/* CHANGEME: render your item fields */}
                        <h3>{item?.name}</h3>
                        <p>{item?.description}</p>
                    </div>
                ))}
            </div>
        </div>
    )
}
