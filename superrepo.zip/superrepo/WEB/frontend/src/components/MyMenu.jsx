import { useState } from 'react'
import { FaHome, FaSearch } from 'react-icons/fa'
import { useNavigate } from 'react-router-dom'

export default function MyMenu() {
    const navigate = useNavigate()
    const [searchTerm, setSearchTerm] = useState('')

    return (
        <header style={{
            position: 'fixed',
            top: 0,
            width: '100%',
            height: '60px',
            backgroundColor: 'rgba(50,50,50,0.85)',  /* CHANGEME */
            display: 'flex',
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center',
            padding: '10px',
            zIndex: 1,
        }}>
            {/* HOME BUTTON */}
            <button
                type="button"
                style={{ background: 'transparent', border: 'none', color: 'white', cursor: 'pointer' }}
                onClick={() => navigate('/')}
            >
                <FaHome size={32} />
            </button>

            {/* SEARCH BAR */}
            <div style={{
                display: 'flex',
                flexDirection: 'row',
                alignItems: 'center',
                gap: 6,
                backgroundColor: 'white',
                borderRadius: '12px',
                padding: '4px 8px',
            }}>
                <input
                    type="text"
                    placeholder="Keresés..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    style={{ border: 'none', background: 'transparent', outline: 'none', padding: '4px' }}
                    onKeyDown={(e) => {
                        if (e.key === 'Enter' && searchTerm.trim().length >= 3) {
                            navigate(`/search/${searchTerm.trim()}`)
                            setSearchTerm('')
                        }
                    }}
                />
                <button
                    type="button"
                    style={{ background: 'transparent', border: 'none', color: 'gray', cursor: 'pointer' }}
                    onClick={() => {
                        if (searchTerm.trim().length >= 3) {
                            navigate(`/search/${searchTerm.trim()}`)
                            setSearchTerm('')
                        }
                    }}
                >
                    <FaSearch size={22} />
                </button>
            </div>
        </header>
    )
}
