import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'

export default function Home() {
    const [items, setItems] = useState([])
    const navigate = useNavigate()

    // ── GET all on mount ─────────────────────────────────────────────────────
    useEffect(() => {
        async function fetchItems() {
            try {
                const res  = await fetch('http://localhost:3333/api/items')
                const data = await res.json()
                setItems(Array.isArray(data) ? data : (data.result ?? []))
            } catch (err) {
                console.warn(err)
            }
        }
        fetchItems()
    }, [])

    // ── POST example ─────────────────────────────────────────────────────────
    async function createItem(payload) {
        try {
            const res = await fetch('http://localhost:3333/api/items', {
                method:  'POST',
                headers: { 'Content-Type': 'application/json' },
                body:    JSON.stringify(payload),
            })
            const data = await res.json()
            console.log('Created:', data)
        } catch (err) {
            console.warn(err)
        }
    }

    // ── PUT example ──────────────────────────────────────────────────────────
    async function updateItem(id, payload) {
        try {
            const res = await fetch(`http://localhost:3333/api/items/${id}`, {
                method:  'PUT',
                headers: { 'Content-Type': 'application/json' },
                body:    JSON.stringify(payload),
            })
            const data = await res.json()
            console.log('Updated:', data)
        } catch (err) {
            console.warn(err)
        }
    }

    // ── DELETE example ───────────────────────────────────────────────────────
    async function deleteItem(id) {
        try {
            const res  = await fetch(`http://localhost:3333/api/items/${id}`, { method: 'DELETE' })
            const data = await res.json()
            console.log('Deleted:', data)
        } catch (err) {
            console.warn(err)
        }
    }

    return (
        <div style={{ marginTop: '80px', padding: '20px' }}>
            <h1 style={{ textAlign: 'center' }}>Főoldal</h1>

            <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: '16px', marginTop: '24px' }}>
                {items.map((item, idx) => (
                    <div
                        key={item?.id ?? idx}
                        onClick={() => navigate(`/items/${item.id}`)}
                        style={{
                            width: '280px',
                            backgroundColor: '#fff',
                            borderRadius: '12px',
                            padding: '16px',
                            boxShadow: '0 2px 8px rgba(0,0,0,0.15)',
                            cursor: 'pointer',
                        }}
                    >
                        {/* CHANGEME: render your item fields */}
                        <h3>{item?.name}</h3>
                        <p>{item?.description}</p>
                    </div>
                ))}
            </div>
        </div>
    )
}
