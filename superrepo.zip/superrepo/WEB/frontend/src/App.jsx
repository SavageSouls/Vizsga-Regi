import { Routes, Route } from 'react-router-dom'
import MyMenu from './components/MyMenu'
import Home from './pages/Home'
import SearchResult from './components/SearchResult'
// import DetailPage from './pages/DetailPage'  // add more pages as needed

function App() {
  return (
    <>
      <MyMenu />
      <Routes>
        <Route path="/"                     element={<Home />} />
        <Route path="/search/:searchedWord" element={<SearchResult />} />
        {/* <Route path="/items/:id"          element={<DetailPage />} /> */}
      </Routes>
    </>
  )
}

export default App
