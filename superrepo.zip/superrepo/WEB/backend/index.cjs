// ════════════════════════════════════════════════════════
//  BACKEND – Express + MySQL2
//  npm init → npm i express cors mysql2
//  node --watch index.cjs
//  Search "CHANGEME" and replace with your values.
// ════════════════════════════════════════════════════════

const express = require('express');
const cors    = require('cors');
const mysql   = require('mysql2');

const app  = express();
const port = 3333;

app.use(cors());
app.use(express.json());

const conn = mysql.createConnection({
    host:     'localhost',
    user:     'root',
    password: '',
    database: 'CHANGEME_DB',   // ← your DB name
});

conn.connect((err) => {
    if (err) console.warn('DB connection error:', err);
    else     console.log('Connected to:', conn.config.database);
});

// ── GET ALL ──────────────────────────────────────────────────────────────────
app.get('/api/items', (req, res) => {
    const sql = `SELECT * FROM CHANGEME_TABLE ORDER BY id ASC`;
    conn.query(sql, (err, result) => {
        if (err) return res.status(500).json({ error: err });
        res.status(200).json(result);
    });
});

// ── GET BY ID (path param) ────────────────────────────────────────────────────
app.get('/api/items/:id', (req, res) => {
    const { id } = req.params;
    const sql = `SELECT * FROM CHANGEME_TABLE WHERE id = ?`;
    conn.query(sql, [id], (err, result) => {
        if (err) return res.status(500).json({ error: err });
        if (result.length === 0) return res.status(404).json({ msg: 'Nem található' });
        res.status(200).json(result);
    });
});

// ── SEARCH (query param: ?q=word) ─────────────────────────────────────────────
app.get('/api/search/:searchWord', (req, res) => {
    const keyword = `%${req.params.searchWord}%`;
    const sql = `
        SELECT * FROM CHANGEME_TABLE
        WHERE name LIKE ? OR description LIKE ?
    `;
    conn.query(sql, [keyword, keyword], (err, result) => {
        if (err) return res.status(500).json({ error: err });
        if (result.length === 0) return res.status(404).json({ msg: 'Nincs találat' });
        res.status(200).json(result);
    });
});

// ── POST (create) ─────────────────────────────────────────────────────────────
app.post('/api/items', (req, res) => {
    const { name, description } = req.body;   // CHANGEME: destructure your fields
    if (!name) return res.status(400).json({ msg: 'Hiányzó adat' });

    const sql = `INSERT INTO CHANGEME_TABLE (name, description) VALUES (?, ?)`;
    conn.query(sql, [name, description], (err, result) => {
        if (err) return res.status(500).json({ error: err });
        res.status(201).json({ msg: 'Sikeres hozzáadás', id: result.insertId });
    });
});

// ── PUT (update) ──────────────────────────────────────────────────────────────
app.put('/api/items/:id', (req, res) => {
    const { id } = req.params;
    const { name, description } = req.body;   // CHANGEME

    const sql = `UPDATE CHANGEME_TABLE SET name = ?, description = ? WHERE id = ?`;
    conn.query(sql, [name, description, id], (err, result) => {
        if (err) return res.status(500).json({ error: err });
        res.status(200).json({ msg: 'Módosítás sikeres', changed: result.changedRows });
    });
});

// ── DELETE ────────────────────────────────────────────────────────────────────
app.delete('/api/items/:id', (req, res) => {
    const { id } = req.params;
    const sql = `DELETE FROM CHANGEME_TABLE WHERE id = ?`;
    conn.query(sql, [id], (err, result) => {
        if (err) return res.status(500).json({ error: err });
        res.status(200).json({ msg: 'Törlés sikeres', affected: result.affectedRows });
    });
});

// ── JOIN EXAMPLE ──────────────────────────────────────────────────────────────
// app.get('/api/joined', (req, res) => {
//     const sql = `
//         SELECT a.id, a.name, b.description
//         FROM CHANGEME_TABLE a
//         JOIN CHANGEME_TABLE2 b ON a.foreign_key = b.id
//         ORDER BY a.name ASC
//     `;
//     conn.query(sql, (err, result) => {
//         if (err) return res.status(500).json({ error: err });
//         res.status(200).json(result);
//     });
// });

// ── DATE FORMAT TIP ───────────────────────────────────────────────────────────
// DATE_FORMAT(column, '%Y-%m-%d %H:%i:%s') AS 'formatted_date'

app.use((req, res) => res.status(404).json({ msg: 'Not found' }));

app.listen(port, () => console.log(`Backend futás: http://localhost:${port}`));
