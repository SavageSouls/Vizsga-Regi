# Superrepo – Részletes magyarázat

## Felépítés
```
superrepo/
├── CLI/
│   ├── Data.java                    ← adatosztály (modell)
│   ├── LoadFromCSV.java             ← fájlbeolvasó segédosztály
│   ├── Main_WITH_streams.java       ← főprogram stream-ekkel
│   └── Main_WITHOUT_streams.java    ← főprogram csak ciklusokkal
├── GUI/
│   ├── MyController_WITH_streams.java
│   ├── MyController_WITHOUT_streams.java
│   └── view.fxml
└── WEB/
    ├── backend/
    │   └── index.cjs
    └── frontend/src/
        ├── main.jsx
        ├── App.jsx
        ├── index.css
        ├── components/
        │   ├── MyMenu.jsx
        │   └── SearchResult.jsx
        └── pages/
            └── Home.jsx
```

---

## CLI – Java parancssoros alkalmazás

### Lépések
1. **Átnevezés**: `Data` → pl. `Repulo`, `Cleaner`, `Booking`
2. **CSV beolvasás** (`LoadFromCSV.java`):
   - Megnyitja a fájlt `StandardCharsets.UTF_8` karakterkódolással
   - Az első sort átugorja (`reader.nextLine()`) – ez a fejléc
   - Soronként split: ha vesszővel van elválasztva → `line.split(",")`, pontosvesszővel → `line.split(";")`
   - Minden sorból létrehoz egy `Data` objektumot és hozzáadja az `ArrayList`-hez
3. **Főprogram** (`Main.java`):
   - A beolvasott listán különböző műveleteket hajt végre
   - Eredményeket `System.out.printf()`-val ír ki
   - Szükség esetén fájlba ment `FileWriter`-rel

### Stream vs. ciklus
| Feladat | Stream | Ciklus |
|---------|--------|--------|
| Szűrés | `.filter(d -> d.getValue() < 100)` | `for` + `if` |
| Max keresés | `.max(Comparator.comparing...)` | `for` + összehasonlítás |
| Distinct | `.distinct()` | `if (!list.contains(...))` |
| Csoportosítás | `Collectors.groupingBy(...)` | `HashMap` + `getOrDefault` |
| Rendezés | `.sorted(Comparator...)` | `list.sort(Comparator...)` |

> **Fontos**: A `list.sort(Comparator...)` (nem stream!) általában mindig legális, mert az nem stream, hanem az `ArrayList` saját metódusa.
> A kérdés inkább a `.stream().collect(Collectors.groupingBy(...))` és a `Stream.map/filter/sorted` jellegű pipeline-ok.

### printf formátumok
```
%s  → String
%d  → int / long
%f  → double (teljes)
%.2f → double (2 tizedesjegy)
%b  → boolean
%n  → sortörés (\n helyett platformfüggetlen)
```

### Fájlba írás
```java
FileWriter writer = new FileWriter(new File("output.txt"), StandardCharsets.UTF_8);
writer.write(sb.toString().trim());
writer.close();
```
Mindig `try-catch`-be kell csomagolni!

---

## GUI – JavaFX ablakos alkalmazás

### Lépések
1. Új JavaFX Maven projekt létrehozása IntelliJ-ben
2. Az FXML fájlban (`view.fxml`) az `fx:controller` attribútumban meg kell adni a controller osztály teljes nevét (pl. `com.example.demo.MyController`)
3. A controller osztályban a `@FXML` annotáció köti össze az FXML elemeket a Java változókkal/metódusokkal

### FXML struktúra
```
VBox (container) – fx:id="container"
  MenuBar
    Menu "Fájl"
      MenuItem "Megnyitás" → onAction="#openFile"
      MenuItem "Kilépés"   → onAction="#exitPlatform"
    Menu "Súgó"
      MenuItem "Névjegy"   → onAction="#handleAbout"
  HBox (radio gombok)
    RadioButton (bal)  fx:id="radioLeft"  → onMouseClicked="#fillLeft"
    RadioButton (jobb) fx:id="radioRight" → onMouseClicked="#fillLeft"
  SplitPane
    ListView fx:id="leftListView"  → onMouseClicked="#fillRight"
    ListView fx:id="rightListView"
```

### ListView feltöltése
```java
ObservableList<String> items = FXCollections.observableArrayList();
items.add("valami");
myListView.setItems(items);
```
Streammel:
```java
ObservableList<String> items = FXCollections.observableArrayList(
    dataList.stream().map(Data::getName).collect(Collectors.toList())
);
```

### Kijelölt elem olvasása
```java
String selected = leftListView.getSelectionModel().getSelectedItem();
```

### Névjegy (About dialog)
```java
Alert alert = new Alert(Alert.AlertType.INFORMATION);
alert.setTitle("Névjegy");
alert.setHeaderText("");
alert.setContentText("Projekt v1.0.0\n(C) Kandó");
alert.showAndWait();
```

### Kilépés
```java
Platform.exit();
```

---

## Backend – Express + MySQL

### Telepítés és indítás
```bash
npm init         # package.json létrehozása (enter×5)
npm i express cors mysql2
node --watch index.cjs
```

### Alap struktúra
```js
const express = require('express');
const cors    = require('cors');
const mysql   = require('mysql2');
const app = express();
const port = 3333;

app.use(cors());
app.use(express.json());

const conn = mysql.createConnection({ host, user, password, database });
conn.connect((err) => { /* ... */ });

app.listen(port, () => console.log(`Running on :${port}`));
```

### Endpointok (route-ok)
| HTTP metódus | Mikor | Mire |
|---|---|---|
| `GET` | Lekérés | Lista, keresés, egy elem |
| `POST` | Létrehozás | Új sor az adatbázisba |
| `PUT` | Módosítás | Meglévő sor frissítése |
| `DELETE` | Törlés | Sor törlése |

### Paraméterek
```js
req.params.id      // URL: /api/items/:id
req.body.name      // JSON body (POST/PUT)
req.query.q        // URL: /api/search?q=hello
```

### SQL futtatás
```js
conn.query(sql, [param1, param2], (err, result) => {
    if (err) return res.status(500).json({ error: err });
    res.status(200).json(result);
});
```

### JOIN minta
```sql
SELECT a.id, a.name, b.description
FROM table_a a
JOIN table_b b ON a.foreign_key = b.id
WHERE a.name LIKE ?
ORDER BY a.name ASC
```

---

## Frontend – React + Vite

### Telepítés
```bash
npm create vite@6 reactapp -- --template react
cd reactapp
npm i react-router-dom react-icons
npm run dev
```

### Routing
- `main.jsx`: `<BrowserRouter>` becsomagolja az `<App />`-ot
- `App.jsx`: `<Routes>` + `<Route path="..." element={<Komponens />} />`
- Navigálás: `const navigate = useNavigate()` → `navigate('/path')`
- URL param olvasása: `const { id } = useParams()`
- Keresési szó olvasása: `const { searchedWord } = useParams()` → route: `/search/:searchedWord`

### Adatlekérés (GET)
```jsx
const [items, setItems] = useState([])

useEffect(() => {
    async function fetchData() {
        const res  = await fetch('http://localhost:3333/api/items')
        const data = await res.json()
        setItems(data)
    }
    fetchData()
}, [])  // ← üres tömb = csak egyszer fut, mountoláskor
```

### POST / PUT / DELETE
```jsx
await fetch('http://localhost:3333/api/items', {
    method:  'POST',          // 'PUT', 'DELETE'
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify({ name: 'valami' }),
})
```

### Kártyák renderelése
```jsx
{items.map((item, idx) => (
    <div key={item?.id ?? idx}>
        <h3>{item.name}</h3>
        <p>{item.description}</p>
    </div>
))}
```

### Navbar keresési mező
- `useState('')` tárolja az aktuális szöveget
- `onKeyDown` figyeli az Enter billentyűt
- `navigate('/search/' + searchTerm)` átirányít a SearchResult oldalra
- Minimum 3 karakter kell a kereséshez (`trim().length >= 3`)

---

## Pontozás és stratégia

| Rész | Pont | Kulcselemek |
|------|------|-------------|
| CLI | 25 | Beolvasás, számítások, printf, fájlírás |
| GUI | 25 | FXML struktúra, ListView, FileChooser, Névjegy |
| Backend | 15 | GET/POST/PUT/DELETE endpointok, SQL |
| Frontend | 25 | Routing, useEffect, map, Navbar, SearchResult |

**Tipp**: A backend és frontend pontok szorosan kapcsolódnak egymáshoz. Ha a backend endpointok rosszak, a frontend sem fog működni – előbb mindig a backendet tesztelsd (pl. böngészőben `http://localhost:3333/api/items`).
