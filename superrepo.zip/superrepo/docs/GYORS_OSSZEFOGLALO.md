# Superrepo – Gyors összefoglaló (puskacédula)

## CLI – Gyors teendők
1. `Data.java` → átnevezni + mezőket átírni  
2. `LoadFromCSV.java` → delimiter: `;` vagy `,` + mezők  
3. `Main_WITH/WITHOUT_streams.java` → TODO-k megcserélése  

**Fájlbeolvasás vázlat:**
```java
Scanner reader = new Scanner(file, StandardCharsets.UTF_8);
reader.nextLine(); // fejléc skip
while (reader.hasNextLine()) {
    String[] parts = reader.nextLine().split(";");
    list.add(new Data(parts[0], parts[1], Integer.parseInt(parts[2])));
}
```
**printf:** `%s %d %.2f %b %n`  
**Fájlírás:** `FileWriter fw = new FileWriter("out.txt", UTF_8); fw.write(...); fw.close();`

---

## GUI – Gyors teendők
1. `view.fxml` → `fx:controller` és `fx:id`-k átírása  
2. `MyController` → `dataList` típusa, `fillLeft/fillRight` logika  

**ListView feltölt:** `listView.setItems(FXCollections.observableArrayList(...))`  
**Kijelölt:** `listView.getSelectionModel().getSelectedItem()`  
**Névjegy:** `new Alert(INFORMATION); alert.setContentText("..."); alert.showAndWait();`  
**Kilépés:** `Platform.exit();`

---

## Backend – Gyors teendők
```bash
npm init && npm i express cors mysql2 && node --watch index.cjs
```
Ctrl+F: **CHANGEME** → DB neve, tábla neve, mezők

| Method | Példa | Param |
|--------|-------|-------|
| GET all | `/api/items` | – |
| GET by id | `/api/items/:id` | `req.params.id` |
| GET search | `/api/search/:word` | `req.params.word` |
| POST | `/api/items` | `req.body.name` |
| PUT | `/api/items/:id` | `req.params.id` + `req.body` |
| DELETE | `/api/items/:id` | `req.params.id` |

```js
conn.query(sql, [param], (err, result) => {
    if (err) return res.status(500).json({ error: err });
    res.status(200).json(result);
});
```

---

## Frontend – Gyors teendők
```bash
npm i react-router-dom react-icons
```
Ctrl+F: **CHANGEME** → URL-ek, mezőnevek, színek

**GET:** 
```jsx
useEffect(() => { fetch('http://localhost:3333/api/items').then(r=>r.json()).then(setItems) }, [])
```
**POST/PUT/DELETE:**
```jsx
fetch(url, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(data) })
```
**URL param:** `const { id } = useParams()`  
**Navigálás:** `const navigate = useNavigate(); navigate('/path')`  
**Render:** `{items.map((item, idx) => <div key={item?.id ?? idx}>{item.name}</div>)}`

---

## Streams vs. Ciklus – gyors összehasonlítás

| Feladat | Stream (WITH) | Ciklus (WITHOUT) |
|---------|--------------|-----------------|
| Szűrés | `.filter(d -> felt.)` | `for` + `if` |
| Max | `.max(Comparator.comparing(D::getV))` | `for` + összehasonlítás |
| Csoportosítás | `Collectors.groupingBy(D::getG)` | `HashMap` + `getOrDefault` |
| Distinct | `.distinct()` | `if (!list.contains(x))` |
| Rendezés | `.sorted(Comparator...)` | `list.sort(Comparator...)` ✓ mindkettőnél OK |
