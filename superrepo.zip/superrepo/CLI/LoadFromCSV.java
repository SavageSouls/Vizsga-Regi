import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class LoadFromCSV {

    // Change "Data" to your class name throughout
    public static List<Data> loadFromCSV(File file) {
        List<Data> list = new ArrayList<>();

        try {
            Scanner reader = new Scanner(file, StandardCharsets.UTF_8);
            // If the CSV has a header line, skip it:
            reader.nextLine();

            while (reader.hasNextLine()) {
                String line = reader.nextLine().trim();
                if (line.isBlank()) continue;

                // Change delimiter to "," if needed
                String[] parts = line.split(";");

                String name  = parts[0];
                String group = parts[1];
                String city  = parts[2];
                double value = Double.parseDouble(parts[3]);

                list.add(new Data(name, group, city, value));
            }
            reader.close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return list;
    }
}
