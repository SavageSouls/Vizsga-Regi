import java.io.File;
import java.io.FileWriter;
import java.nio.charset.StandardCharsets;
import java.util.*;

// ════════════════════════════════════════════════════════
//  CLI MAIN – WITHOUT STREAMS (loops only)
//  Search for TODO and replace with task-specific logic.
// ════════════════════════════════════════════════════════
public class Main {
    public static void main(String[] args) {

        // ── 1. LOAD ──────────────────────────────────────────────────────────
        List<Data> list = LoadFromCSV.loadFromCSV(new File("data.csv"));
        System.out.printf("Összesen %d sor beolvasva.%n", list.size());

        // ── 2. RANDOM ────────────────────────────────────────────────────────
        Random random = new Random();
        Data randomItem = list.get(random.nextInt(list.size()));
        System.out.printf("Véletlenszerű elem: %s%n", randomItem.getName());

        // ── 3. MAX / MIN ─────────────────────────────────────────────────────
        Data maxItem = list.get(0);
        Data minItem = list.get(0);
        for (Data d : list) {
            if (d.getValue() > maxItem.getValue()) maxItem = d;
            if (d.getValue() < minItem.getValue()) minItem = d;
        }
        System.out.printf("Max: %s (%.2f)%n", maxItem.getName(), maxItem.getValue());
        System.out.printf("Min: %s (%.2f)%n", minItem.getName(), minItem.getValue());

        // ── 4. FILTER + AVERAGE ──────────────────────────────────────────────
        List<Data> filtered = new ArrayList<>();
        for (Data d : list) {
            if (d.getValue() < 100) filtered.add(d); // TODO: change condition
        }
        double sum = 0;
        for (Data d : filtered) sum += d.getValue();
        double avg = filtered.isEmpty() ? 0 : sum / filtered.size();
        System.out.printf("Szűrt elemek (%d db) átlaga: %.2f%n", filtered.size(), avg);

        // ── 5. SORT (bubble or Collections.sort) ─────────────────────────────
        // Option A – built-in comparator (still no streams):
        list.sort(Comparator.comparingDouble(Data::getValue).reversed());
        System.out.printf("Legtöbb: %s (%.2f)%n", list.get(0).getName(), list.get(0).getValue());

        // Option B – manual bubble sort:
        /*
        for (int i = 0; i < list.size() - 1; i++) {
            for (int j = 0; j < list.size() - 1 - i; j++) {
                if (list.get(j).getValue() < list.get(j+1).getValue()) {
                    Data tmp = list.get(j);
                    list.set(j, list.get(j+1));
                    list.set(j+1, tmp);
                }
            }
        }
        */

        // ── 6. DISTINCT VALUES ───────────────────────────────────────────────
        List<String> groups = new ArrayList<>();
        for (Data d : list) {
            if (!groups.contains(d.getGroup())) groups.add(d.getGroup());
        }
        System.out.println("Csoportok: " + String.join(", ", groups));

        // ── 7. GROUP BY → COUNT (HashMap) ────────────────────────────────────
        HashMap<String, Integer> countByGroup = new HashMap<>();
        for (Data d : list) {
            String key = d.getGroup();
            countByGroup.put(key, countByGroup.getOrDefault(key, 0) + 1);
        }
        for (Map.Entry<String, Integer> entry : countByGroup.entrySet()) {
            System.out.printf("  %s: %d%n", entry.getKey(), entry.getValue());
        }

        // ── 8. REGEX – contains digit ────────────────────────────────────────
        List<Data> noDigit = new ArrayList<>();
        for (Data d : list) {
            if (!d.getName().matches(".*\\d.*")) noDigit.add(d);
        }
        System.out.println("Számot nem tartalmazó nevek: " + noDigit.size());

        // ── 9. FILE WRITE ────────────────────────────────────────────────────
        StringBuilder sb = new StringBuilder();
        for (Data d : list) {
            if (d.getValue() > 300) { // TODO: change condition
                sb.append(d.getName()).append(" / ").append(d.getValue()).append("\n");
            }
        }
        try {
            FileWriter writer = new FileWriter(new File("output.txt"), StandardCharsets.UTF_8);
            writer.write(sb.toString().trim());
            writer.close();
            System.out.println("Mentés sikeres: output.txt");
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        // ── PRINTF CHEAT SHEET ───────────────────────────────────────────────
        // %s = String, %d = int/long, %f = double, %.2f = 2 tized, %b = boolean, %n = newline
    }
}
