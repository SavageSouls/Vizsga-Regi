import java.io.File;
import java.io.FileWriter;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.stream.*;

// ════════════════════════════════════════════════════════
//  CLI MAIN – WITH STREAMS (generators / collectors)
//  Search for TODO and replace with task-specific logic.
// ════════════════════════════════════════════════════════
public class Main {
    public static void main(String[] args) {

        // ── 1. LOAD ──────────────────────────────────────────────────────────
        List<Data> list = LoadFromCSV.loadFromCSV(new File("data.csv"));
        System.out.printf("Összesen %d sor beolvasva.%n", list.size());

        // ── 2. RANDOM ────────────────────────────────────────────────────────
        Random random = new Random();
        Data randomItem = list.get(random.nextInt(list.size()));
        System.out.printf("Véletlenszerű elem: %s%n", randomItem.getName());

        // ── 3. MAX / MIN ─────────────────────────────────────────────────────
        Optional<Data> maxOpt = list.stream().max(Comparator.comparingDouble(Data::getValue));
        Optional<Data> minOpt = list.stream().min(Comparator.comparingDouble(Data::getValue));
        maxOpt.ifPresent(d -> System.out.printf("Max érték: %s (%.2f)%n", d.getName(), d.getValue()));
        minOpt.ifPresent(d -> System.out.printf("Min érték: %s (%.2f)%n", d.getName(), d.getValue()));

        // ── 4. FILTER + AVERAGE ──────────────────────────────────────────────
        List<Data> filtered = list.stream()
                .filter(d -> d.getValue() < 100)   // TODO: change condition
                .collect(Collectors.toList());

        double avg = filtered.stream()
                .collect(Collectors.averagingDouble(Data::getValue));
        System.out.printf("Szűrt elemek (%d db) átlaga: %.2f%n", filtered.size(), avg);

        // ── 5. SORT + TOP-N ──────────────────────────────────────────────────
        List<Data> top3 = list.stream()
                .sorted(Comparator.comparingDouble(Data::getValue).reversed())
                .limit(3)
                .collect(Collectors.toList());
        System.out.println("Top 3:");
        top3.forEach(d -> System.out.printf("  %s: %.2f%n", d.getName(), d.getValue()));

        // ── 6. DISTINCT VALUES ───────────────────────────────────────────────
        List<String> groups = list.stream()
                .map(Data::getGroup)
                .filter(Objects::nonNull)
                .distinct()
                .collect(Collectors.toList());
        System.out.println("Csoportok: " + String.join(", ", groups));

        // ── 7. GROUP BY → COUNT ──────────────────────────────────────────────
        Map<String, Long> countByGroup = list.stream()
                .collect(Collectors.groupingBy(Data::getGroup, Collectors.counting()));

        // ── 8. GROUP BY → SUM ────────────────────────────────────────────────
        Map<String, Double> sumByGroup = list.stream()
                .collect(Collectors.groupingBy(Data::getGroup, Collectors.summingDouble(Data::getValue)));

        // ── 9. SORT MAP DESC ─────────────────────────────────────────────────
        Map<String, Long> sortedDesc = countByGroup.entrySet().stream()
                .sorted(Map.Entry.<String, Long>comparingByValue().reversed())
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (a, b) -> a, LinkedHashMap::new));
        sortedDesc.forEach((k, v) -> System.out.printf("  %s: %d%n", k, v));

        // ── 10. REGEX – contains digit ───────────────────────────────────────
        List<Data> noDigit = list.stream()
                .filter(d -> !d.getName().matches(".*\\d.*"))
                .collect(Collectors.toList());
        System.out.println("Számot nem tartalmazó nevek: " + noDigit.size());

        // ── 11. FILE WRITE ───────────────────────────────────────────────────
        StringBuilder sb = new StringBuilder();
        list.stream()
                .filter(d -> d.getValue() > 300)   // TODO: change condition
                .forEach(d -> sb.append(d.getName()).append(" / ").append(d.getValue()).append("\n"));

        try {
            FileWriter writer = new FileWriter(new File("output.txt"), StandardCharsets.UTF_8);
            writer.write(sb.toString().trim());
            writer.close();
            System.out.println("Mentés sikeres: output.txt");
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        // ── PRINTF CHEAT SHEET ───────────────────────────────────────────────
        // %s = String, %d = int/long, %f = double, %.2f = 2 tized, %b = boolean, %n = newline
    }
}
