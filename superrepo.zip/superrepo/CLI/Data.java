// Rename "Data" to your entity (e.g. Repulo, Cleaner, Booking…)
// Rename fields to match your CSV columns
public class Data {
    String name;
    String group;
    String city;
    double value;

    public String getName()  { return name; }
    public void setName(String name) { this.name = name; }

    public String getGroup() { return group; }
    public void setGroup(String group) { this.group = group; }

    public String getCity()  { return city; }
    public void setCity(String city) { this.city = city; }

    public double getValue() { return value; }
    public void setValue(double value) { this.value = value; }

    public Data(String name, String group, String city, double value) {
        this.setName(name);
        this.setGroup(group);
        this.setCity(city);
        this.setValue(value);
    }
}
