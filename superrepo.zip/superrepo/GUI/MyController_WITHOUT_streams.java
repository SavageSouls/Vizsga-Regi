package com.example.demo;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

// ════════════════════════════════════════════════════════
//  GUI CONTROLLER – WITHOUT STREAMS (loops only)
//  Search for TODO, rename "Data" to your class.
// ════════════════════════════════════════════════════════
public class MyController {

    @FXML public VBox container;
    @FXML public ListView<String> leftListView;
    @FXML public ListView<String> rightListView;
    @FXML public RadioButton radioLeft, radioRight;

    private static List<Data> dataList = new ArrayList<>();

    // ── FILE OPEN ────────────────────────────────────────────────────────────
    @FXML
    public void openFile() {
        Stage currentStage = (Stage) container.getScene().getWindow();
        try {
            FileChooser fc = new FileChooser();
            fc.setTitle("Fájl kiválasztása...");
            fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("CSV fájl", "*.csv"));
            File selected = fc.showOpenDialog(currentStage);

            if (selected != null) dataList = LoadFromCSV.loadFromCSV(selected);
            else                  dataList = LoadFromCSV.loadFromCSV(new File("data.csv"));

            fillLeft();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    // ── LEFT LIST ────────────────────────────────────────────────────────────
    @FXML
    public void fillLeft() {
        ObservableList<String> items = FXCollections.observableArrayList();

        if (radioLeft.isSelected()) {
            // TODO: fill items for left radio option (loop, no streams)
            List<String> seen = new ArrayList<>();
            for (Data d : dataList) {
                if (!seen.contains(d.getGroup())) {
                    seen.add(d.getGroup());
                    items.add(d.getGroup());
                }
            }
        } else {
            // TODO: fill items for right radio option
            for (Data d : dataList) {
                items.add(d.getName());
            }
        }

        leftListView.setItems(items);
        rightListView.getItems().clear();
    }

    // ── RIGHT LIST ───────────────────────────────────────────────────────────
    @FXML
    public void fillRight() {
        String selected = leftListView.getSelectionModel().getSelectedItem();
        if (selected == null) return;

        ObservableList<String> details = FXCollections.observableArrayList();
        for (Data d : dataList) {
            // TODO: change condition to match your logic
            if (d.getGroup().equals(selected)) {
                details.add(d.getName() + " – " + d.getValue());
            }
        }
        rightListView.setItems(details);
    }

    // ── MENU: EXIT ───────────────────────────────────────────────────────────
    @FXML
    public void exitPlatform() {
        Platform.exit();
    }

    // ── MENU: ABOUT ──────────────────────────────────────────────────────────
    @FXML
    public void handleAbout() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Névjegy");
        alert.setHeaderText("");
        alert.setContentText("Projekt v1.0.0\n(C) Kandó");
        alert.showAndWait();
    }
}
