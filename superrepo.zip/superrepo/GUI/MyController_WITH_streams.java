package com.example.demo;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

// ════════════════════════════════════════════════════════
//  GUI CONTROLLER – WITH STREAMS
//  Search for TODO, rename "Data" to your class.
// ════════════════════════════════════════════════════════
public class MyController {

    @FXML public VBox container;
    @FXML public ListView<String> leftListView;
    @FXML public ListView<String> rightListView;
    @FXML public RadioButton radioLeft, radioRight;
    // public ToggleGroup radio;  ← declare in FXML only, reference via $radio

    private static List<Data> dataList = new ArrayList<>();

    // ── FILE OPEN ────────────────────────────────────────────────────────────
    @FXML
    public void openFile() {
        Stage currentStage = (Stage) container.getScene().getWindow();
        try {
            FileChooser fc = new FileChooser();
            fc.setTitle("Fájl kiválasztása...");
            fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("CSV fájl", "*.csv"));
            File selected = fc.showOpenDialog(currentStage);

            if (selected != null) dataList = LoadFromCSV.loadFromCSV(selected);
            else                  dataList = LoadFromCSV.loadFromCSV(new File("data.csv"));

            fillLeft();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    // ── LEFT LIST ────────────────────────────────────────────────────────────
    @FXML
    public void fillLeft() {
        ObservableList<String> items;

        if (radioLeft.isSelected()) {
            // TODO: change what to show for left radio option
            items = FXCollections.observableArrayList(
                dataList.stream()
                    .map(Data::getGroup)
                    .distinct()
                    .collect(Collectors.toList())
            );
        } else {
            // TODO: change what to show for right radio option
            items = FXCollections.observableArrayList(
                dataList.stream()
                    .map(Data::getName)
                    .collect(Collectors.toList())
            );
        }

        leftListView.setItems(items);
        rightListView.getItems().clear();
    }

    // ── RIGHT LIST (click/key on left list) ──────────────────────────────────
    @FXML
    public void fillRight() {
        String selected = leftListView.getSelectionModel().getSelectedItem();
        if (selected == null) return;

        // TODO: filter dataList based on what was selected in leftListView
        ObservableList<String> details = FXCollections.observableArrayList(
            dataList.stream()
                .filter(d -> d.getGroup().equals(selected))
                .map(d -> d.getName() + " – " + d.getValue())
                .collect(Collectors.toList())
        );
        rightListView.setItems(details);
    }

    // ── MENU: EXIT ───────────────────────────────────────────────────────────
    @FXML
    public void exitPlatform() {
        Platform.exit();
    }

    // ── MENU: ABOUT ──────────────────────────────────────────────────────────
    @FXML
    public void handleAbout() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Névjegy");
        alert.setHeaderText("");
        alert.setContentText("Projekt v1.0.0\n(C) Kandó");
        alert.showAndWait();
    }
}
