# Superrepo

## Tartalom
```
CLI/
  Data.java                    ← modell osztály (átnevezendő)
  LoadFromCSV.java             ← CSV beolvasó
  Main_WITH_streams.java       ← főprogram stream-ekkel
  Main_WITHOUT_streams.java    ← főprogram csak ciklusokkal

GUI/
  MyController_WITH_streams.java
  MyController_WITHOUT_streams.java
  view.fxml

WEB/
  backend/index.cjs            ← Express + MySQL2 (npm i express cors mysql2)
  frontend/src/
    main.jsx / App.jsx / index.css
    components/MyMenu.jsx      ← Navbar keresővel
    components/SearchResult.jsx
    pages/Home.jsx             ← GET + kártyák

docs/
  RESZLETES_MAGYARAZAT.md     ← részletes leírás
  GYORS_OSSZEFOGLALO.md       ← puskacédula
```

## Gyors start
1. Ctrl+F: **CHANGEME** / **TODO** → cseréld ki a feladatnak megfelelőre
2. CLI: `Data.java` mezői = CSV oszlopok, `LoadFromCSV` splitje = CSV elválasztója
3. GUI: `view.fxml` fx:controller + fx:id-k, controller fillLeft/fillRight logikája
4. Backend: `database`, táblanév, mezők; `node --watch index.cjs`
5. Frontend: `npm i react-router-dom react-icons`; fetch URL-ek; item mezők a kártyákban

## Streams kérdése
- **WITH streams**: `Main_WITH_streams.java`, `MyController_WITH_streams.java`
- **WITHOUT streams**: `Main_WITHOUT_streams.java`, `MyController_WITHOUT_streams.java`
- `list.sort(Comparator...)` MINDKÉT verzióban OK – ez nem stream
